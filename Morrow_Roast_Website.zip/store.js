const roasts = {
  daybreak: { name: 'Daybreak Blend', price: 58, tasting: 'orange zest and honey' },
  classic: { name: 'Morrow Classic', price: 62, tasting: 'milk chocolate and caramel' },
  reserve: { name: 'Evening Reserve', price: 65, tasting: 'dark cocoa and roasted hazelnut' },
};

const storageKey = 'morrow-roast-bag';
const quantities = {};
try {
  const saved = JSON.parse(localStorage.getItem(storageKey)) || {};
  for (const id of Object.keys(roasts)) {
    if (Number.isSafeInteger(saved[id]) && saved[id] > 0) quantities[id] = saved[id];
  }
} catch {
  // The bag is still usable when browser storage is disabled.
}

const bag = document.querySelector('#bag');
const bagItems = document.querySelector('#bag-items');
const notice = document.querySelector('#notice');
const money = (amount) => 'AED ' + amount;

function renderBag() {
  let count = 0;
  let subtotal = 0;
  bagItems.replaceChildren();
  for (const [id, quantity] of Object.entries(quantities)) {
    const roast = roasts[id];
    count += quantity;
    subtotal += quantity * roast.price;
    const row = document.createElement('div');
    row.className = 'bag-row';
    const label = document.createElement('span');
    label.textContent = roast.name + ' × ' + quantity + ' · ' + money(quantity * roast.price);
    const remove = document.createElement('button');
    remove.className = 'outline';
    remove.textContent = 'Remove one';
    remove.setAttribute('aria-label', 'Remove one ' + roast.name);
    remove.addEventListener('click', () => {
      updateQuantity(id, -1);
      (bagItems.querySelector('button') || bag.querySelector('button')).focus();
    });
    row.append(label, remove);
    bagItems.append(row);
  }
  if (!count) bagItems.textContent = 'Your bag is empty.';
  document.querySelector('#count').textContent = count;
  document.querySelector('#subtotal').textContent = count ? 'Subtotal · ' + money(subtotal) : '';
}

function updateQuantity(id, change) {
  const quantity = (quantities[id] || 0) + change;
  if (quantity > 0) quantities[id] = quantity;
  else delete quantities[id];
  try {
    localStorage.setItem(storageKey, JSON.stringify(quantities));
  } catch {
    // Keep the current session working.
  }
  renderBag();
}

document.querySelectorAll('[data-add]').forEach((button) => {
  button.addEventListener('click', () => {
    const id = button.dataset.add;
    updateQuantity(id, 1);
    notice.textContent = roasts[id].name + ' added to your bag (' + quantities[id] + ').';
  });
});
document.querySelector('#open-bag').addEventListener('click', () => bag.showModal());
document.querySelector('#finder').addEventListener('submit', (event) => {
  event.preventDefault();
  const roast = roasts[document.querySelector('#flavor').value];
  const method = document.querySelector('#method').value;
  const tips = {
    'Pour over': 'Try a medium grind to bring out its tasting notes.',
    'French press': 'Use a coarse grind for a fuller-bodied cup.',
    Espresso: 'Start with a fine grind and adjust it to taste.',
  };
  document.querySelector('#match').textContent =
    roast.name + ' matches your taste with notes of ' + roast.tasting + '. ' + tips[method];
});
renderBag();
