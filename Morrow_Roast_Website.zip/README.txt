Morrow Roast | PixelCraft Creative Studio

Open index.html in a browser to preview. For Netlify, extract this ZIP
and drop the extracted folder containing index.html into Netlify Drop.
No build command, package installation, or environment variables are needed.

This is a fictional storefront. The bag is a browser-local demo, and prices
are illustrative. The site does not collect payments or submit orders.
